# CricketersInfo: https://cricketerinfo.netlify.app/index.html
About Me:
Hello I Am Vikas Kumar UnderGraduate At N.I.T RAIPUR Pursuing Electrical Engineering I Love To Play And Watch Cricket And You May Know My Favourite Cricketer Till Now That Is King Kohli As Obvious
Inspiration For Making This Website:
I Used To Wonder That There Should Be A Website Which In Seconds Gives You Everything Related To A Particular Cricketer So That Is My Inspiration, And I am Glad That I am Able To Develop It.
What This Website Do?
This Website Let's You Search For Your Favorite Cricketer And You Will Get Every Thing Related To Your Favorite Cricketer, You Can Search Any Cricketer's Name That You Want, You Will Get Info About It.
Special Credits:
This Website Uses An Unofficial CricBuzz API So Special Thanks To Developer Of This API, Please Give Your FeedBack That Is Crucial For Me.

